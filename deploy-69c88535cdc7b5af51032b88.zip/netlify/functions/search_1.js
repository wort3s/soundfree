// netlify/functions/search.js
// Proxy para búsqueda de YouTube sin API key
// Parsea los resultados de youtube.com directamente

exports.handler = async (event) => {
  const q = event.queryStringParameters?.q;
  if (!q) return { statusCode: 400, body: 'Missing query' };

  try {
    const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}&sp=EgIQAQ%3D%3D`;
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'es-MX,es;q=0.9,en;q=0.8',
      }
    });

    const html = await res.text();

    const match = html.match(/var ytInitialData = (\{.+?\});\s*<\/script>/s);
    if (!match) {
      return { statusCode: 500, body: JSON.stringify({ error: 'No data found' }) };
    }

    const data = JSON.parse(match[1]);
    const contents =
      data?.contents?.twoColumnSearchResultsRenderer?.primaryContents
          ?.sectionListRenderer?.contents || [];

    const videos = [];
    for (const section of contents) {
      const items = section?.itemSectionRenderer?.contents || [];
      for (const item of items) {
        const v = item?.videoRenderer;
        if (!v?.videoId) continue;

        const durText = v.lengthText?.simpleText || '';
        const durSec = durText
          ? durText.split(':').reverse().reduce((acc, t, i) => acc + (parseInt(t) || 0) * Math.pow(60, i), 0)
          : 0;

        // Filtrar videos muy cortos o muy largos
        if (durSec > 0 && (durSec < 60 || durSec > 7200)) continue;

        // Detectar si el video tiene embedding deshabilitado
        // YouTube incluye "isEmbeddable" o badges que indican restricciones
        const badges = v.badges || [];
        const isLive = badges.some(b => 
          b?.metadataBadgeRenderer?.label === 'EN DIRECTO' ||
          b?.metadataBadgeRenderer?.label === 'LIVE'
        );
        if (isLive) continue; // los directos no son canciones

        // Verificar que tenga título válido
        const title = v.title?.runs?.[0]?.text || '';
        if (!title) continue;

        const artist = v.ownerText?.runs?.[0]?.text || '';
        const thumb = v.thumbnail?.thumbnails?.slice(-1)[0]?.url || 
          `https://i.ytimg.com/vi/${v.videoId}/mqdefault.jpg`;

        // Verificar embeddable via oEmbed antes de incluir
        // Solo verificar los primeros 5 para no tardar demasiado
        videos.push({
          id: v.videoId,
          title,
          artist: artist.replace(/\s*[-–]\s*Topic\s*$/i, '').trim(),
          durSec,
          dur: durText || '—',
          thumb: thumb.startsWith('//') ? 'https:' + thumb : thumb,
        });

        if (videos.length >= 30) break;
      }
      if (videos.length >= 30) break;
    }

    // Verificar cuáles son embeddables consultando oEmbed en paralelo
    // oEmbed falla (404) para videos con embedding deshabilitado
    const checkEmbeddable = async (id) => {
      try {
        const r = await fetch(
          `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${id}&format=json`,
          { signal: AbortSignal.timeout(3000) }
        );
        return r.ok;
      } catch(_) {
        return true; // si falla la verificación, dejar pasar (mejor que quitar de más)
      }
    };

    const embeddableChecks = await Promise.all(videos.map(v => checkEmbeddable(v.id)));
    const filtered = videos.filter((_, i) => embeddableChecks[i]).slice(0, 25);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'public, max-age=300',
      },
      body: JSON.stringify(filtered),
    };

  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
};

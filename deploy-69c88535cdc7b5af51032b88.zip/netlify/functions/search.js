// netlify/functions/search.js
// Proxy para búsqueda de YouTube sin API key
// Parsea los resultados de youtube.com directamente

exports.handler = async (event) => {
  const q = event.queryStringParameters?.q;
  if (!q) return { statusCode: 400, body: 'Missing query' };

  try {
    const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}&sp=EgIQAQ%3D%3D`; // EgIQAQ = solo videos
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'es-MX,es;q=0.9,en;q=0.8',
      }
    });

    const html = await res.text();

    // YouTube embebe los resultados en un objeto JS dentro del HTML
    const match = html.match(/var ytInitialData = (\{.+?\});\s*<\/script>/s);
    if (!match) {
      return { statusCode: 500, body: JSON.stringify({ error: 'No data found' }) };
    }

    const data = JSON.parse(match[1]);
    const contents =
      data?.contents?.twoColumnSearchResultsRenderer?.primaryContents
          ?.sectionListRenderer?.contents || [];

    const videos = [];
    for (const section of contents) {
      const items = section?.itemSectionRenderer?.contents || [];
      for (const item of items) {
        const v = item?.videoRenderer;
        if (!v?.videoId) continue;

        const durText = v.lengthText?.simpleText || '';
        const durSec = durText
          ? durText.split(':').reverse().reduce((acc, t, i) => acc + (parseInt(t) || 0) * Math.pow(60, i), 0)
          : 0;

        const title = v.title?.runs?.[0]?.text || '';
        const artist = v.ownerText?.runs?.[0]?.text || '';
        const thumb = v.thumbnail?.thumbnails?.slice(-1)[0]?.url || `https://i.ytimg.com/vi/${v.videoId}/mqdefault.jpg`;

        // Filtrar videos muy cortos (< 60s) y muy largos (> 2h) — probablemente no son canciones
        if (durSec > 0 && (durSec < 60 || durSec > 7200)) continue;

        videos.push({
          id: v.videoId,
          title,
          artist: artist.replace(/\s*[-–]\s*Topic\s*$/i, '').trim(),
          durSec,
          dur: durText || '—',
          thumb: thumb.startsWith('//') ? 'https:' + thumb : thumb,
        });

        if (videos.length >= 25) break;
      }
      if (videos.length >= 25) break;
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'public, max-age=300', // cache 5 minutos
      },
      body: JSON.stringify(videos),
    };

  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
};
